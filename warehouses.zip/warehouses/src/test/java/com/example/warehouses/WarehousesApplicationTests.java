package com.example.warehouses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehousesApplicationTests {

	@Test
	void contextLoads() {
	}

}
